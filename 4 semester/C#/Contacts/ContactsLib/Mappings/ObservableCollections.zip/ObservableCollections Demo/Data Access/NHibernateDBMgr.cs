using System.Data.SqlClient;
using NHibernate.Cfg;

namespace NHibernate.Examples.ObservableCollections.DataAccess {
	/// <summary>
	/// Object encapsulating data access via NHibernate.
	/// </summary>
	public class NHibernateDBMgr : System.IDisposable {
		#region Static Members

		private static ISessionFactory sessionFactory;

		private static ISessionFactory SessionFactory {
			get {
				if ( sessionFactory == null )
					sessionFactory = new Configuration().Configure().BuildSessionFactory();
				return sessionFactory;
			}
		}

		#endregion

		private ISession session;

		public NHibernateDBMgr() {
			session = SessionFactory.OpenSession(); // open new session
		}

		/// <summary>
		/// Loads the specified object from the database.
		/// </summary>
		/// <typeparam name="T">Type of object to load</typeparam>
		/// <param name="id">Identifier of object to load</param>
		/// <returns>Object as specified from the database; otherwise NULL if
		/// the object could not be found.</returns>
		public T Get<T>( object id ) {
			return session.Get<T>( id );
		}

		/// <summary>
		/// Updates an object that already exists within the database.
		/// </summary>
		public void Update( object o ) {
			session.Update( o );
			session.Flush();
		}

		/// <summary>
		/// Save a new object to the database.
		/// </summary>
		public void Save( object o ) {
			session.Save( o );
			session.Flush();
		}

		/// <summary>
		/// Delete an object from the database.
		/// </summary>
		public void Delete( object o ) {
			session.Delete( o );
			session.Flush();
		}

		#region IDisposable Members

		public void Dispose() {
			session.Close(); // close session
		}

		#endregion
	}
}
