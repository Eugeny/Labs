using System;
using System.Windows;
using System.Configuration;

namespace Example {
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>

	public partial class App : System.Windows.Application {

	}
}