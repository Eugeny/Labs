using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

using NHibernate.Collection.Observable;
using NHibernate.Examples.ObservableCollections;
using NHibernate.Examples.ObservableCollections.DataAccess;

namespace NHibernate.Examples.ObservableCollections.GUI {

	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>
	public partial class Window1 : System.Windows.Window {
		private SampleSetContainer sampleSetContainer;
		private SampleListContainer sampleListContainer;

		public Window1() { InitializeComponent(); }

		private void this_Loaded( object sender, RoutedEventArgs e ) {
			// load the set and list containers from database, then bind their items to list boxes
			using ( NHibernateDBMgr dbMgr = new NHibernateDBMgr() ) {
				sampleSetContainer = dbMgr.Get<SampleSetContainer>( 1 );
				sampleSetBox.ItemsSource = sampleSetContainer.SampleSet;
				sampleListContainer = dbMgr.Get<SampleListContainer>( 2 );
				sampleListBox.ItemsSource = sampleListContainer.SampleList;
			}
		}

		private void ItemSelectionChange( object s, RoutedEventArgs e ) {
			ListBox sender = (ListBox)s;
			if ( sender.SelectedItem == null ) return;
			SampleItem selectedItem = (SampleItem)sender.SelectedItem;
			editItemBox.Text = selectedItem.Name; // display item name in text box
			((sender == sampleSetBox) ? sampleListBox : sampleSetBox).UnselectAll(); // deselect in other box
		}

		private void addButton_Click( object sender, RoutedEventArgs e ) {
			SampleItem newItem = new SampleItem();
			newItem.Name = editItemBox.Text; // add new item from value in text box
			sampleSetContainer.SampleSet.Add( newItem );  // execute either this line or the next
			//newItem.ParentSetContainer = sampleSetContainer;
			using ( NHibernateDBMgr dbMgr = new NHibernateDBMgr() )
				dbMgr.Save( newItem );
		}

		private void copyToButton_Click( object sender, RoutedEventArgs e ) {
			if ( sampleSetBox.SelectedItem == null ) return;
			SampleItem selectedItem = (SampleItem)sampleSetBox.SelectedItem;
			sampleListContainer.SampleList.Add( selectedItem );
			using ( NHibernateDBMgr dbMgr = new NHibernateDBMgr() )
				dbMgr.Update( sampleListContainer );
		}

		private void updateButton_Click( object sender, RoutedEventArgs e ) {
			object selectedContainer; SampleItem selectedItem;
			if ( !GetSelection(out selectedContainer , out selectedItem) ) return;
			selectedItem.Name = editItemBox.Text; // update selected item from value in text box
			using ( NHibernateDBMgr dbMgr = new NHibernateDBMgr() )
				dbMgr.Update( selectedItem );
		}

		private void deleteButton_Click( object sender, RoutedEventArgs e ) {
			object selectedContainer; SampleItem selectedItem;
			if ( !GetSelection(out selectedContainer , out selectedItem) ) return;

			if ( selectedContainer is SampleSetContainer ) { // then delete item from set
				sampleSetContainer.SampleSet.Remove( selectedItem ); // execute either this line or the next
				//selectedItem.ParentSetContainer = null;
				using ( NHibernateDBMgr dbMgr = new NHibernateDBMgr() ) {
					if ( sampleListContainer.SampleList.Contains( selectedItem ) )
						dbMgr.Update( selectedItem );
					else dbMgr.Delete( selectedItem );
				}
			} else { // delete item from list
				sampleListContainer.SampleList.Remove( selectedItem );
				using ( NHibernateDBMgr dbMgr = new NHibernateDBMgr() ) {
					dbMgr.Update( selectedContainer );
					if ( !(sampleSetContainer.SampleSet.Contains( selectedItem ) ||
						sampleListContainer.SampleList.Contains( selectedItem )) )
						dbMgr.Delete( selectedItem );
				}
			}
		}

		private bool GetSelection( out object selectedContainer , out SampleItem selectedItem ) {
			if ( sampleSetBox.SelectedItem != null ) {
				selectedContainer = sampleSetContainer;
				selectedItem = (SampleItem)sampleSetBox.SelectedItem;
				return true;
			} else if ( sampleListBox.SelectedItem != null ) {
				selectedContainer = sampleListContainer;
				selectedItem = (SampleItem)sampleListBox.SelectedItem;
				return true;
			} else {
				selectedContainer = null;
				selectedItem = null;
				return false;
			}
		}
	}
}
