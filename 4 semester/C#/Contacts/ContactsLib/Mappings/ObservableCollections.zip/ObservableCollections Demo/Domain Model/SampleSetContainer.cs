using System;
using System.Collections.Specialized;

using HappyNomad.BidirectionalAssociations;
using Iesi.Collections.Generic;

namespace NHibernate.Examples.ObservableCollections {

	/// <summary>
	/// A parent class that contains a set of child <see cref="SampleItem"/> objects.
	/// </summary>
	public class SampleSetContainer {
		private int id;
		private ISet<SampleItem> sampleSet;

		public virtual int ID {
			get { return id; }
			protected set { id = value; }
		}

		public virtual ISet<SampleItem> SampleSet {
			get { return sampleSet; }
			protected set {
				sampleSet = value;
				((INotifyCollectionChanged)sampleSet).CollectionChanged +=
					new OneToManyAssocSync( this, "ParentSetContainer" ).UpdateManySide;
			}
		}
	}
}
