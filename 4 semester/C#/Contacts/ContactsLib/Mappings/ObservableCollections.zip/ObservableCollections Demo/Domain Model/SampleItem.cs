using System;
using System.Collections.Generic;
using System.ComponentModel;

using HappyNomad.BidirectionalAssociations;

namespace NHibernate.Examples.ObservableCollections {

	public class SampleItem : INotifyPropertyChanged {
		private int id;
		private string name;
		private SampleSetContainer parentSetContainer;

		public virtual int ID {
			get { return id; }
			protected set { id = value; }
		}

		public virtual string Name {
			get { return name; }
			set {
				name = value;
				OnPropertyChanged( "Name" );
			}
		}

		public virtual SampleSetContainer ParentSetContainer {
			get { return parentSetContainer; }
			set {
				System.Console.WriteLine( "setting sample item's parent set container" );
				SampleSetContainer oldParentSetContainer = parentSetContainer;
				parentSetContainer = value;
				OneToManyAssocSync.UpdateOneSide( this, oldParentSetContainer, parentSetContainer, "SampleSet" );
			}
		}

		#region INotifyPropertyChanged Members

		public virtual event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged( string propertyName ) {
			if ( PropertyChanged != null )
				PropertyChanged( this, new PropertyChangedEventArgs( propertyName ) );
		}

		#endregion

	}
}
