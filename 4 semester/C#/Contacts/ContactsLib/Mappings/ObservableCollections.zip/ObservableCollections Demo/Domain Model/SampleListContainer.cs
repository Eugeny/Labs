using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;

namespace NHibernate.Examples.ObservableCollections {

	/// <summary>
	/// A parent class that contains a list of child <see cref="SampleItem"/> objects.
	/// </summary>
	public class SampleListContainer {
		private int id;
		private IList<SampleItem> sampleList;

		public virtual int ID {
			get { return id; }
			protected set { id = value; }
		}

		public virtual IList<SampleItem> SampleList {
			get { return sampleList; }
			protected set {
				sampleList = value;
				((INotifyCollectionChanged)sampleList).CollectionChanged += value_CollectionChanged;
			}
		}

		private void value_CollectionChanged( object sender, NotifyCollectionChangedEventArgs e ) {
			if ( e.Action == NotifyCollectionChangedAction.Add )
				foreach ( SampleItem item in e.NewItems )
					System.Console.WriteLine( "new item added to the list" );
			else if ( e.Action == NotifyCollectionChangedAction.Remove )
				foreach ( SampleItem item in e.OldItems )
					System.Console.WriteLine( "item removed from the list" );
		}
	}
}
